import cy from "cypress";

class mainPage {
  // Open URL
  static navigate() {
    cy.viewport(1920, 1080);
    cy.visit({ timeout: 100000 });
  }
}
export default mainPage;
